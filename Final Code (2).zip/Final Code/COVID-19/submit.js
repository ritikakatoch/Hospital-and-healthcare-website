function myFunction() {
  alert("Idea Submitted Successfully");
}
