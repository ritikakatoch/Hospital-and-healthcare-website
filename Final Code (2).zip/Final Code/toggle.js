$(document).ready(function(){
		$("#info").click(function(){
			$("#hideshow").toggle();
	});
});