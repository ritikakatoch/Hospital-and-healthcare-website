$(document).ready(function(){
	$("#close").click(function(){
		$(".notification").hide();
		$(".navbar .fixed-top").css("top","0px");
	});
});